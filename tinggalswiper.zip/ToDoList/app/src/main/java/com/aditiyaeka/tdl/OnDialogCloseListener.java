package com.aditiyaeka.tdl;

import android.content.DialogInterface;

public interface OnDialogCloseListener {
    void onDialogClose(DialogInterface dialogInterface);
}
